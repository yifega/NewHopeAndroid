# New Hope Cooperative Android app

This Android Studio project creates a lightweight Android WebView app for the existing HTTPS site:

`https://newhopempcsl.com/`

It does not replace, copy, or modify the PHP/MySQL backend. Members' data and login sessions remain on the existing website/server.

## Included
- Android launcher app named **New Hope Cooperative**
- HTTPS-only site loading
- JavaScript, DOM storage and first-party cookies for existing login/session flows
- Android back navigation
- File chooser support for website upload forms
- External links handed to the appropriate phone app/browser
- Basic offline/error message

## Build an installable APK

1. Install **Android Studio** on a computer.
2. Extract this project ZIP.
3. In Android Studio choose **Open** and select the `NewHopeAndroid` folder.
4. Allow Gradle sync and install the Android SDK platform 35 if prompted.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK will be created at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to the Android phone and install it. Android may ask to allow installation from that file manager/browser.

For a signed release APK, use **Build > Generate Signed Bundle / APK** and create a private signing key. Keep the keystore and passwords private and backed up.

## Important pre-release checks
- Verify that `https://newhopempcsl.com/` is the correct live production domain and that all member/admin routes work on mobile.
- Test member login, logout, forms, file uploads, downloads, payment redirects, password reset and admin access on real Android devices.
- The supplied PHP configuration in the project archive contains deployment placeholders, including a default admin password and a placeholder sensitive-data encryption key. Before exposing the backend publicly, replace these with strong unique secrets, rotate any default credentials, and verify the live server configuration. Do not put server credentials or database dumps in the Android app.
- The app requires internet access. It is not an offline copy of the PHP/MySQL system.
